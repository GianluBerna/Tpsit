# TPSIT_4AROB
Lezioni ed esercitazioni di TPSIT per la classe 4AROB 2019/20
